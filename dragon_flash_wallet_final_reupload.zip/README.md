# Dragon Flash Wallet

A Web3 wallet frontend built with Next.js and styled for dark mode with a dragon logo.