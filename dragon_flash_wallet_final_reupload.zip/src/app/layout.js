export const metadata = {
  title: 'Dragon Flash Wallet',
  description: 'Your Web3 Wallet Interface',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0 }}>{children}</body>
    </html>
  );
}