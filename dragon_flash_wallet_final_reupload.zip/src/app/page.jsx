import Image from 'next/image';
import logo from '/public/logo.png';

export default function Home() {
  return (
    <main style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100vh',
      backgroundColor: '#111',
      color: '#fff',
      fontFamily: 'Arial, sans-serif'
    }}>
      <Image src={logo} alt="Dragon Logo" width={200} height={200} />
      <h1 style={{ marginTop: '20px', fontSize: '2rem' }}>Dragon Flash Wallet</h1>
      <button style={{
        marginTop: '20px',
        padding: '10px 20px',
        fontSize: '1rem',
        backgroundColor: '#e63946',
        color: '#fff',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer'
      }}>Connect Wallet</button>
    </main>
  );
}